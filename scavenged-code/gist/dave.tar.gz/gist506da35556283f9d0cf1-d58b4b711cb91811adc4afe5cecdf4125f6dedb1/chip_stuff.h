#ifndef CHIP_STUFF_H
#define CHIP_STUFF_H

#define arrSize 30             //size of the array
#define hallPin 0
#define tempPin 0

#endif
